# Tetris-Game-in-Python-without-Pygame-
This is a game of Tetris implemented in Python using OOP concepts which was done in 3rd semester as a part of SSAD course.
