1) This is a readme file for Bomberman game created as part of assignment without using any library like pygame or ncurses.
2) The game controls are w -> go up
			 s -> go down
			 d -> go right
			 a -> go left
			 b -> put bomb
3) The game will be over when all the enemies were killed.
4) You can quit the game by pressing 'q' key in keyboard.
5) Run the game by running file actboard.py in python3.
