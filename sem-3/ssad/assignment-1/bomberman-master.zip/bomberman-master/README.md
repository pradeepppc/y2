BOMBERMAN
=========

- Using python2.7
- check requirements.txt for other dependencies
  - install them with 'pip install -r requirements.txt'
  - to add more dependencies, use pip and: 'pip freeze > requirements.txt'
