import os

ROOT_DIR = os.path.join(os.path.dirname(__file__), '..')
LEVEL_DIR = os.path.join(ROOT_DIR, 'levels')
LEVEL_EXT = '.level'
