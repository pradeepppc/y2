1) q1.c is the code for task-1 . You should first compile it and type command "./a.out <input file>" where input file is the test case file.
2) The output of the above code will be stored in file named "output.txt" in the "Assignment" directory.
3) As we need executive permissions to enter into directory I have also given executive permissions to the user.
4) After running the command please go into the directory and open the file "output.txt". 
5) q2.c is the code for task-2 and again usage is to type command "./a.out <input file>" .
6) Symbolic link for the output.txt is named as "linkoutput.txt" and will be in present directory.(not "Assignment" directory).
