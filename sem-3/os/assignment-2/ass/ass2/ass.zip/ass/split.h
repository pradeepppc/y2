#ifndef SPLIT
#define SPLIT
void split(char command[]);
#endif
