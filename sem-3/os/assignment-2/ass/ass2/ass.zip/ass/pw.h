#ifndef PWD
#define PWD
void pwd();

#endif
