#ifndef LS
#define LS
void ls2(char *tok);
void ls(char *token);
#endif
