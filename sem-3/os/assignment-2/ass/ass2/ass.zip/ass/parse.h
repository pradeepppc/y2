#ifndef PARSE
#define PARSE
void  parse(char *line, char **argv);
#endif
