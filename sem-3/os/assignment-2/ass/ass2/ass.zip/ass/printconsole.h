#ifndef PRINT
#define PRINT
void prbash();
#endif
