#ifndef PINFO
#define PINFO
void pinfo(char *token);
#endif
