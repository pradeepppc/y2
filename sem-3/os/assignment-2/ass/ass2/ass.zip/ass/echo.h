#ifndef ECHO
#define ECHO
void echo(char *token);
#endif
