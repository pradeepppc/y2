#ifndef COMMAND
#define COMMAND
void purecom(char command[]);
#endif
