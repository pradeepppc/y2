#ifndef CD
#define CD

void cd(char *token);

#endif
