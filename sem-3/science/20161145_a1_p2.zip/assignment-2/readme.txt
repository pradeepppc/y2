1) First create a empty file named output.xyz then run python <q2.py>.
2) It will ask for number of particles and number of steps.
3) Output will be a graph and also the output.xyz file contains the required coordinates .
