1.This is a readme file for first problem.
2.First if you run the program it will ask for number of experiments i mean number of trails.
3.Then it will ask for number of steps.
4.please enter numbers in range of 1000 because the inner loop is O(n^3).
5.The output will be a graph required.
 
