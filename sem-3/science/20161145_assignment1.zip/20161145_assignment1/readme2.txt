1)This is a readme file for 2 question.
2)First enter number of particles at centre.
3)Then enter number of steps.
4)The output will be the graph between S(r) and r.
5)where r is radius and S(r) is number of particles at a distance r from center of Sphere.
